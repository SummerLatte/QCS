
【RAF-DB】
	           【training】	             【val】
Surprise	0	1290		329	
Fear	1	281		74
Disgust	2	717		160
Happy	3	4772		1185
Sad	4	1982		478
Anger	5	705		162
Neutral	6	2524		680
total		12271		3068




【FERPlus】
	           【training】	               【val】
Neutral	 0	8740		1090
Happy	 1	7287		893
Surprise	 2	3149		396
Sad	 3	3014		384
Anger	 4	2100		273
Disgust	 5	119		18
Fear	 6	532		83
Contempt	 7	119		16
total		25060		3153



【Affect-7-v1】
	             【training】              【val】
Neutral	0	74874		500
Happy	1	134415		500
Sad	2	25459		500
Surprise	3	14090		500
Fear	4	6378		500
Disgust	5	3803		500
Anger	6	24882		500
total                         283901		3500

【Affect-7-v2】
	             【training】              【val】
Neutral	0	74874		500
Happy	1	134415		500
Sad	2	25459		500
Surprise	3	14090		500
Fear	4	6378+615+355	500
Disgust	5	3803+137+877	500
Anger	6	24882		500
total                         283901+1984	3500


【Affect-7-v7】
	             【training】              【val】
Neutral	0	74874		500
Happy	1	134415		500
Sad	2	25459		500
Surprise	3	14090		500
Fear	4	(6378+615+355)*2	500
Disgust	5	(3803+137+877)*3	500
Anger	6	24882		500
total                         283901+18,966	3500



【Affect-7-v6】(oversampling)	
                             【training】              【val】
Neutral	0	75374		500
Happy	1	134415		500
Sad	2	50918		500
Surprise	3	28180		500
Fear	4	25512		500
Disgust	5	22818		500
Anger	6	49764		500
total                         386481		3500


【Affect-8-v1】
	             【training】              【val】
Neutral	0	74874		500
Happy	1	134415		500
Sad	2	25459		500
Surprise	3	14090		500
Fear	4	6378		500
Disgust	5	3803		500
Anger	6	24882		500
Contempt 7              3750                         500
total                         287651		4000


【Affect-8-v2】
	             【training】              【val】
Neutral	0	74874		500
Happy	1	134415		500
Sad	2	25459		500
Surprise	3	14090		500
Fear	4	6378+615+355	500
Disgust	5	3803+137+877	500
Anger	6	24882		500
Contempt 7              3750+135                 500
total                         287651+2119	4000


【Affect-8-v7】
	             【training】              【val】
Neutral	0	74874		500
Happy	1	134415		500
Sad	2	25459		500
Surprise	3	14090		500
Fear	4	(6378+615+355)*2	500
Disgust	5	(3803+137+877)*3	500
Anger	6	24882		500
Contempt 7              (3750+135)*4            500
total                         287651+30,756	4000

14,696  14,451   
    8,318+10,648


【Affect-8-v6】
	             【training】              【val】
Neutral	0	74874		500
Happy	1	134415		500
Sad	2	50918		500
Surprise	3	28180		500
Fear	4	25512		500
Disgust	5	22818		500
Anger	6	49764		500
Contempt 7              22500                       500
total                         408981		4000





